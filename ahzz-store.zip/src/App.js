import React, { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

const products = [
  {
    id: 1,
    name: 'WhatsApp Image 2025-07-16 at 20.04.45_1302e26e',
    price: 1999,
    sizes: ['S', 'M', 'L', 'XL'],
    image: 'https://via.placeholder.com/300x400?text=WhatsApp+Image+Shirt'
  },
  {
    id: 2,
    name: 'Kids Streetwear Set',
    price: 1499,
    sizes: ['2Y', '3Y', '4Y', '5Y'],
    image: 'https://via.placeholder.com/300x400?text=WhatsApp+Image+2025-07-16+at+20.04.45_51d2aae1'
  }
];

export default function AhzzStore() {
  const [cart, setCart] = useState([]);

  const addToCart = (product, size) => {
    if (!size) return alert('Please select a size.');
    setCart([...cart, { ...product, size }]);
  };

  const [form, setForm] = useState({
    name: '',
    email: '',
    phone: '',
    address: ''
  });

  const handleOrder = () => {
    if (!form.name || !form.phone || !form.email || !form.address) {
      alert('Please fill all fields');
      return;
    }
    const message = `New Order from Ahzz\nName: ${form.name}\nEmail: ${form.email}\nPhone: ${form.phone}\nAddress: ${form.address}\nItems: ${cart
      .map(c => `\n- ${c.name} (${c.size}) - Rs.${c.price}`)
      .join('')}\n\nPayment: Easypaisa or SadaPay`;

    window.open(`https://wa.me/923360127064?text=${encodeURIComponent(message)}`);
  };

  return (
    <div className="p-6 space-y-10">
      <h1 className="text-4xl font-bold text-center">Ahzz ایز Clothing</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {products.map(product => (
          <Card key={product.id} className="p-4">
            <img src={product.image} alt={product.name} className="rounded-xl w-full h-96 object-cover" />
            <CardContent className="space-y-2">
              <h2 className="text-2xl font-semibold">{product.name}</h2>
              <p className="text-lg">Rs. {product.price}</p>
              <select
                className="border p-2 rounded w-full"
                onChange={e => product.selectedSize = e.target.value}
              >
                <option>Select Size</option>
                {product.sizes.map(size => (
                  <option key={size} value={size}>{size}</option>
                ))}
              </select>
              <Button
                className="w-full"
                onClick={() => addToCart(product, product.selectedSize)}
              >
                Add to Cart
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>

      {cart.length > 0 && (
        <div className="p-4 border rounded-xl bg-gray-50">
          <h2 className="text-2xl font-bold mb-4">🛒 Your Cart</h2>
          <ul className="mb-4">
            {cart.map((item, index) => (
              <li key={index}>- {item.name} ({item.size}) – Rs. {item.price}</li>
            ))}
          </ul>

          <div className="space-y-3">
            <input
              type="text"
              placeholder="Your Name"
              className="w-full border p-2 rounded"
              onChange={e => setForm({ ...form, name: e.target.value })}
            />
            <input
              type="email"
              placeholder="Email"
              className="w-full border p-2 rounded"
              onChange={e => setForm({ ...form, email: e.target.value })}
            />
            <input
              type="text"
              placeholder="WhatsApp Number"
              className="w-full border p-2 rounded"
              onChange={e => setForm({ ...form, phone: e.target.value })}
            />
            <textarea
              placeholder="Full Address"
              className="w-full border p-2 rounded"
              onChange={e => setForm({ ...form, address: e.target.value })}
            />
            <Button className="w-full bg-green-600" onClick={handleOrder}>
              📦 Place Order on WhatsApp
            </Button>
          </div>
        </div>
      )}

      <footer className="text-center pt-10 text-sm text-gray-500">
        © 2025 Ahzz ایز – Designed with ❤️ in Pakistan
      </footer>
    </div>
  );
}